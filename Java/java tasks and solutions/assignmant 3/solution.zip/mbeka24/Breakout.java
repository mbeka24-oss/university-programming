/*
 /*
 * File: Breakout.java
 * -------------------
 * Name:
 * Section Leader:
 * 
 * This file will eventually implement the game of Breakout.
 */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Breakout extends GraphicsProgram {

	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 600;

	private static final int WIDTH = APPLICATION_WIDTH;
	private static final int HEIGHT = APPLICATION_HEIGHT;

	private static final int PADDLE_WIDTH = 60;
	private static final int PADDLE_HEIGHT = 10;

	private static final int PADDLE_Y_OFFSET = 30;

	private static final int NBRICKS_PER_ROW = 10;

	private static final int NBRICK_ROWS = 10;

	private static final int BRICK_SEP = 4;

	private static final int BRICK_WIDTH =
	  (WIDTH - (NBRICKS_PER_ROW - 1) * BRICK_SEP) / NBRICKS_PER_ROW;

	private static final int BRICK_HEIGHT = 8;

	private static final int BALL_RADIUS = 10;

	private static final int BRICK_Y_OFFSET = 50;

	private static final int NTURNS = 3; 
	
	private static final int G = 4;
	
	private final RandomGenerator randomGenerator = RandomGenerator.getInstance();
	
	private static final Color RED_COLOR = Color.RED;
	
	private static final Color ORANGE_COLOR = Color.ORANGE;
	
	private static final Color YELLOW_COLOR = Color.YELLOW; 
	
	private static final Color GREEN_COLOR = Color.GREEN;
	
	private static final Color CYAN_COLOR = Color.CYAN;
	
	private GRect paddle;
	
	private double dx;
	
	private double NUMBER_OF_BRICK_ALIVE = NBRICKS_PER_ROW * NBRICK_ROWS;
	
	private int HEALTH = 3;
	
	private int second = 1;//how much time u want to stop ball after u lose health point
	
	private int ballStopTime = 1000 * second; //nothing special
	
	private double minX = 5;
	
	private double maxX = 8;
	
	private int vY = 3;

	private GOval ball;
	
	private double vX;

	@Override
	public void run() {	
		
		addMouseListeners();	
		paddle();		
		buildColumn();
		level_1();	
	}
	public void level_1() {
	    ball = build_ball();
	    vX = random_Number_x();
	    

	    while (HEALTH != 0 && NUMBER_OF_BRICK_ALIVE > 0) {
	    	ball.move(vX, vY);
	    	bounceFromWalls2();
	    	bounce();
	        pause(15);
	    }
	    endOfTheGame();
	}
	//removes everything  and it say you win or you lose
	private void endOfTheGame(){
		if(NUMBER_OF_BRICK_ALIVE == 0){
	    	removeAll();
	    	GLabel win = new GLabel("you win");
	    	win.setFont("Serif-48");
	    	win.setLocation(WIDTH / 2 - win.getWidth() / 2, HEIGHT / 2 - win.getHeight() / 2);	
	    	
	    	add(win);
        }
	    if(HEALTH == 0){
	    	removeAll();
	    	GLabel lose = new GLabel("you lose");
	    	lose.setFont("Serif-48");
	    	lose.setLocation(WIDTH / 2 - lose.getWidth() / 2, HEIGHT / 2 - lose.getHeight() / 2);
	    	add(lose);
	    }
	}
	//bounceFromWalls real code
	private void bounceFromWalls1(double leftX, double rightX, double ballupY, double balldownY ){
		
        if (rightX >= WIDTH) {
            vX *= -1;
            ball.setLocation(WIDTH - 2 * BALL_RADIUS, ball.getY()); 
        }else
        
        if (leftX <= 0) {
            vX *= -1;
            ball.move(-2 * ball.getX(), 0);
        }else
        
        if (balldownY >= HEIGHT) {
            HEALTH = HEALTH - 1;
            ball.setLocation(APPLICATION_WIDTH / 2 - BALL_RADIUS / 2 , (APPLICATION_HEIGHT - BALL_RADIUS) /2);
            pause(ballStopTime);
        }else
        if (ballupY <= 0) {
            vY *= -1;
        }
	}
	//bounceFromWalls remake code
	private void bounceFromWalls2(){
		//only 1 coordinate x or y
        double leftX = ball.getX();
    	double rightX = ball.getX() + 2 * BALL_RADIUS;
    	double ballupY = ball.getY();
    	double balldownY = ball.getY() + 2 * BALL_RADIUS;
    	bounceFromWalls1(leftX, rightX, ballupY, balldownY);
	}
	//bounceFromPaddle
	private void bounceFromPaddle(GObject middle_up, GObject middle_down, GObject middle_left, GObject middle_right){
		if (ball.getY() + 2 * BALL_RADIUS >= paddle.getY() &&
	        	ball.getX() + BALL_RADIUS >= paddle.getX() &&
	        	 ball.getX() + BALL_RADIUS <= paddle.getX() + PADDLE_WIDTH
	        	    ) {
	        	vY = -(Math.abs(vY));
	        }
		
	}
	//bounces and removes bricks
	private void bounce(){
		//ball parts(west, east, north, south) middle ones
        GObject middle_up = getElementAt(ball.getX() + BALL_RADIUS, ball.getY() - 2);
        GObject middle_down = getElementAt(ball.getX() + BALL_RADIUS, ball.getY() + 2 * BALL_RADIUS - 2);
        GObject middle_left = getElementAt(ball.getX() - 2, ball.getY() + BALL_RADIUS); 
        GObject middle_right = getElementAt(ball.getX() + 2 * BALL_RADIUS + 2, ball.getY() + BALL_RADIUS);  
        bounceFromPaddle(middle_up, middle_down, middle_left, middle_right);
        removeBricks1(middle_up, middle_down);
        removeBricks2( middle_left, middle_right);
	}
    //another if ckecs if there is brick and brick will be removed and vx will change
	//removes blocks when ball touches from up or down

	private void removeBricks1 (GObject middle_up, GObject middle_down){
        if(ball.getY() < HEIGHT / 2){
        	if (middle_up != null) {
	            if (middle_up !=paddle && middle_up != ball) {
	                vY = -vY;
	                remove(middle_up);
	                NUMBER_OF_BRICK_ALIVE = NUMBER_OF_BRICK_ALIVE - 1;
	            }
	        }
        }
        
        //another if ckecs if there is brick and brick will be removed and vy will change
    	//removes blocks when ball touches from up or down

        if(ball.getY() < HEIGHT / 2){
        	if (middle_down != null) {
	            if (middle_down != paddle && middle_down != ball) {
	                vY = -vY;
	                NUMBER_OF_BRICK_ALIVE = NUMBER_OF_BRICK_ALIVE - 1;

	                remove(middle_down);
	            }
	        }
        }
   
	}
	//removes blocks when ball touches from left or right
	private void removeBricks2(GObject middle_left, GObject middle_right){
    //first if  avoids unnecessary checks
        //another if ckecs if there is brick and brick will be removed and vx will change

        if (ball.getX() < WIDTH / 2) {
            
            if (middle_left != null) {
                if (middle_left != paddle && middle_left != ball) {
                    vX = -vX;  
	                NUMBER_OF_BRICK_ALIVE = NUMBER_OF_BRICK_ALIVE - 1;

                    remove(middle_left); 	                }
            }
        }
        //first if  avoids unnecessary checks
        //another if ckecs if there is brick and brick will be removed and vx will change

        if (ball.getX() > WIDTH / 2) {
            if (middle_right != null) {
                if (middle_right != paddle && middle_right != ball) {
                    vX = -vX;
                    remove(middle_right); 
	                NUMBER_OF_BRICK_ALIVE = NUMBER_OF_BRICK_ALIVE - 1;

                }
            }
        }
	}
	//creates bricks
	private void buildColumn(){
		for(double x = 0; x < NBRICKS_PER_ROW; x++){
			for(double y = 0; y < NBRICK_ROWS; y++){
			//x coordinate ox every brick
			double xCoordinate = BRICK_SEP / 2 + x * (BRICK_SEP + BRICK_WIDTH); 
			//y coordinate of every brick
			double yCoordinate = BRICK_Y_OFFSET + (BRICK_SEP + BRICK_HEIGHT) * y ;
				GRect rectangle = new GRect(xCoordinate, yCoordinate, BRICK_WIDTH, BRICK_HEIGHT);
				
				rectangle.setColor(brickColor(y));
				rectangle.setFillColor(brickColor(y));
				rectangle.setFilled(true);
				add(rectangle);
			}
		}
	}
	//returns color of bricks per row
	public Color brickColor(double y){
		if(y < 2){
			return (RED_COLOR);
			
		}else if(y < 4){
			return (ORANGE_COLOR);
			
		}else if(y < 6){
			return (YELLOW_COLOR);

		}else if(y < 8){
			return (GREEN_COLOR);

		}else {
			return (CYAN_COLOR);
		}
		
	}
	//creates paddle
	public void paddle(){
		paddle = new GRect((WIDTH - PADDLE_WIDTH) / 2, HEIGHT - PADDLE_Y_OFFSET - PADDLE_HEIGHT, PADDLE_WIDTH, PADDLE_HEIGHT);
		paddle.setFilled(true);
		add(paddle);
	}
	//padle ball
	public GOval build_ball(){
		GOval ball = new GOval(APPLICATION_WIDTH / 2 - BALL_RADIUS / 2 , (APPLICATION_HEIGHT - BALL_RADIUS) /2, BALL_RADIUS * 2, 2 * BALL_RADIUS);
	    ball.setFilled(true);
	    add(ball);
	    return ball;
	}
	@Override 	
	//paddle goes to kursor location
	public void mouseMoved(MouseEvent e) {
		//new x is location of paddle
		double newX = e.getX() - dx; 
		if (newX < 0) {
			newX = 0;
		} else if (newX > WIDTH - PADDLE_WIDTH) {
			newX = WIDTH - PADDLE_WIDTH;
		}
		paddle.setLocation(newX, HEIGHT - PADDLE_Y_OFFSET - PADDLE_HEIGHT); 
		
	}
	//generates random number from min to max  and then multiple -1 or 1
	private double random_Number_x(){
		
		double x = randomGenerator.nextDouble(minX,maxX);
		double y = randomGenerator.nextInt(0,1);
		if (y == 0) {
			x = -x;
		}
		return x;
	}
}