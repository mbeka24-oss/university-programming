/*
 * File: ProgramHierarchy.java
 * Name: 
 * Section Leader: 
 * ---------------------------
 * This file is the starter file for the ProgramHierarchy problem.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

//in this code i think you do not need much comments, because it is coordinates 
public class ProgramHierarchy extends GraphicsProgram {	
	//rectangle width
	private static final int WIDTH = 150;
	//rectangle height
	private static final int HEIGHT = 60;
	//space between rectanles
	private static final int WIDTH_SPACE = 60;
	//space beatwen rectangle
	private static final int HEIGHT_SPACE = 60;
	//names of labels
	private static final String PROGRAM = "graphics program";
	private static final String GRARAPHICS = "console program";
	private static final String CONSOLE = "dialog program";
	private static final String DIALOG = "program";
	public void run() {
		ProgramHierarchy();
	}
	
	private void ProgramHierarchy(){
		//3 lines that connects rectangles
		lines();
		//rectangles, where are symbols written 
		rectangles();
		//just labels 
		labels();
	}
	private void lines(){
		line1();
		line2();
		line3();
	}
	private void rectangles(){
		rectangle1();
		rectangle2();
		rectangle3();
		rectangle4();
	}
	private void labels(){
		label1();
		label2();
		label3();
		label4();
	}
	
	private void rectangle1(){
		
		double x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2;
		double y =  getHeight() / 2 + HEIGHT_SPACE / 2 ;
		
		GRect body = new GRect (x, y, WIDTH, HEIGHT);
		
		
		add(body);
	}
	private void rectangle2(){
		double x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH_SPACE + WIDTH;
		double y =  getHeight() / 2 + HEIGHT_SPACE / 2 ;
		
		GRect body = new GRect (x, y, WIDTH, HEIGHT);
		
		
		add(body);
	}
	private void rectangle3(){
		double x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + (WIDTH_SPACE + WIDTH) * 2;
		double y = getHeight() / 2 + HEIGHT_SPACE / 2 ;
		
		GRect body = new GRect (x, y, WIDTH, HEIGHT);
		
		
		add(body);
	}
	private void rectangle4(){
		double x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH_SPACE + WIDTH;
		double y = getHeight() / 2 - HEIGHT_SPACE / 2 - HEIGHT;
		
		GRect body = new GRect (x, y, WIDTH, HEIGHT);
		
		
		add(body);
	}
	
	private void line1(){
		add(new GLine(
				(getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH / 2, getHeight() / 2 + HEIGHT_SPACE / 2 ,
				getWidth() / 2 , getHeight() / 2 - HEIGHT_SPACE / 2 
				));
		
	}
	private void line2(){
		add(new GLine(
				getWidth() / 2, getHeight() / 2 + HEIGHT_SPACE / 2 ,
				getWidth() / 2 , getHeight() / 2 - HEIGHT_SPACE / 2 
				));
		
	}
	private void line3(){
		add(new GLine(
				getWidth() - ((getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH / 2), getHeight() / 2 + HEIGHT_SPACE / 2 ,
				getWidth() / 2 , getHeight() / 2 - HEIGHT_SPACE / 2 
				));
		
}
	
	private void label1(){ 
	    GLabel program = new GLabel(PROGRAM);
	    // x and y are cordinates of rectangles
	    //rectangle no 1 cordinates: x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2  
	    //y = getHeight() / 2 + HEIGHT_SPACE / 2

	    // Center the label horizontally and vertically in rectangle1
	    add(program,
	    	(getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH / 2 - program.getWidth() / 2,
	    	getHeight() / 2 + HEIGHT_SPACE / 2 + HEIGHT / 2 + program.getAscent() / 2
	    );
	    
	}
	private void label2(){
		GLabel graphicsProgram = new GLabel(GRARAPHICS);
		
		//rectangle no 2 cordinates: x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH_SPACE + WIDTH;  
	    //y = getHeight() / 2 + HEIGHT_SPACE / 2;  

	    // Center the label in rectangle2
	    add(graphicsProgram,
	    	(getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH_SPACE + WIDTH + WIDTH / 2 - graphicsProgram.getWidth() / 2,
	    	getHeight() / 2 + HEIGHT_SPACE / 2 + HEIGHT / 2 + graphicsProgram.getAscent() / 2
	    );
	    
	}
	private void label3(){
		GLabel consoleProgram = new GLabel(CONSOLE);
	    //erctangle no 3 cordinates: x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + (WIDTH_SPACE + WIDTH) * 2;  
	    // y = getHeight() / 2 + HEIGHT_SPACE / 2;  

	    // Center the label in rectangle3
	    add(consoleProgram,
	    	(getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + (WIDTH_SPACE + WIDTH) * 2 + WIDTH / 2 - consoleProgram.getWidth() / 2,
	    	getHeight() / 2 + HEIGHT_SPACE / 2 + HEIGHT / 2 + consoleProgram.getAscent() / 2
	    );
	    
	}
	private void label4(){
		GLabel dialogProgram = new GLabel(DIALOG);
		//rectangle no 4 cordinates: x = (getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH_SPACE + WIDTH; 
	    // y = getHeight() / 2 - HEIGHT_SPACE / 2 - HEIGHT; 

	    // Center the label in rectangle4
	    add(dialogProgram,
	    	(getWidth() - 3 * WIDTH - 2 * WIDTH_SPACE) / 2 + WIDTH_SPACE + WIDTH + WIDTH / 2 - dialogProgram.getWidth() / 2,
	    	getHeight() / 2 - HEIGHT_SPACE / 2 - HEIGHT + HEIGHT / 2 + dialogProgram.getAscent() / 2
	    );
	}
	
}

