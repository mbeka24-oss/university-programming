/*
 * File: Hailstone.java
 * Name: 
 * Section Leader: 
 * --------------------
 * This file is the starter file for the Hailstone problem.
 */

import acm.program.*;

public class Hailstone extends ConsoleProgram {
	public void run() {
		//first number 
		int x = readInt("enter a number ");
		//number that will counts how many steps need calculations to end 
		int m = 0;
		//cycle
		while(x != 1){
			//if it it even do n / 2
			int k = x % 2;
			if(k == 0){
				x = x / 2;
				m = m + 1;
				println("your number is even, so i make 3n + 1 :" + x);
			}
			else{
				////if it it odd do 3n + 1
				x = x * 3 + 1;
				println("your number is odd, so i take half :" + x);
			}
		}
		//show results
		println("the process took " + m + " to reach 1");
		
	}
}

