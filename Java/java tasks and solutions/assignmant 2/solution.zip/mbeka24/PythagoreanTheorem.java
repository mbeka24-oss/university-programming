/*
 * File: PythagoreanTheorem.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

import acm.program.*;

public class PythagoreanTheorem extends ConsoleProgram {
	public void run() {
		println("enter greater than 0 two integer");
		//this two are integers which is equal to 2 cathetus of triangle
		int a, b;
		
		a = readInt("write a: ");
		
		b = readInt("write b: ");
		//this code helps us to avoid the integers that can't be Cathetus of triangle
		while(a <= 0 || b <= 0){
			//rewrite a integer if a is not greater than 0
			if(a <= 0){
				println("a can't be the number you wrote");
				a = readInt("write a: ");
			}
			//rewrite b integer if a is not greater than 0
			if(b <= 0){
				println("b can't be the number you wrote");
				b = readInt("write b: ");
			}
		}
		//this finds hypotenuse of triangle 
		double c = Math.sqrt(a * a + b * b);
		println(c);

	}
	
}
