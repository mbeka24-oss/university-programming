/*
 * File: Target.java
 * Name: 
 * Section Leader: 
 * -----------------
 * This file is the starter file for the Target problem.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Target extends GraphicsProgram {
	//big circle sizze
	private static final int BIG_OVAL = 144;
	//small sized circle, its  size depends on big circle size
	private static final double SMALL_OVAL = BIG_OVAL * (0.76 / 2.54);
	//average sized circle, its  size depends on big circle size
	private static final double NORMAL_OVAL = BIG_OVAL * (1.65 / 2.54);
	private static final Color RED_COLOR = Color.RED;
	private static final Color WHITE_COLOR = Color.WHITE;
	
	
	private void target(){
		bigOlav();
		normalOlav();
		smallOlav();
	}
	//big circle code
	private void bigOlav(){
		//all of this is coordinates, it must be in middle
		double x = getWidth() / 2 - BIG_OVAL / 2;
		double y = getHeight() / 2 - BIG_OVAL / 2;
		GOval oval = new GOval(x, y, BIG_OVAL, BIG_OVAL);
		//color
		oval.setFilled(true);
		oval.setFillColor(RED_COLOR);
		add(oval);
	}
	private void normalOlav(){
		//all of this is coordinates, it must be in middle
		double x = getWidth() / 2- NORMAL_OVAL  / 2;
		double y = getHeight() / 2 - NORMAL_OVAL  / 2;
		GOval oval = new GOval(x, y, NORMAL_OVAL , NORMAL_OVAL );
		//color(white)
		oval.setFilled(true);
		oval.setFillColor(WHITE_COLOR);
		add(oval);
	}
	private void smallOlav(){
		//all of this is coordinates, it must be in middle
		double x = getWidth() /2 - SMALL_OVAL/ 2;
		double y = getHeight() / 2 - SMALL_OVAL / 2;
		GOval oval = new GOval(x, y,SMALL_OVAL, SMALL_OVAL);
		//color(red)
		oval.setFilled(true);
		oval.setFillColor(RED_COLOR);
		add(oval);
	}
	public void run() {
		target();

	}
	
}
