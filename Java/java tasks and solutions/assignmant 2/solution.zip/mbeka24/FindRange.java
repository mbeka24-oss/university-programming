/*
 * File: FindRange.java
 * Name: 
 * Section Leader: 
 * --------------------
 * This file is the starter file for the FindRange problem.
 */

import acm.program.*;

public class FindRange extends ConsoleProgram {
	
	//breaking number
	private static final int SYMBOL = 0;
	
	public void run() {
		println("This program finds the largest and smallest numbers ");
		
		
		//min number
		int x = readInt("?");
		//max number
		int z = x;
		//
		if(x == SYMBOL){
			println("there is no min and max number you write");
		}
		//cycle while you do not enter symbol to stop this process
		while(x != SYMBOL){
			//just number 
			int y = readInt("?");
			//this code will match your written number to min and max
			if( y != SYMBOL){
				//finds if your number is min
				if(y < x){
					x = y;					
				//finds if your number is max
				}
				if(y > z){
					z = y;
				}
			}
			//code will end if y = 0
			else{
				//shows min and max number you wrote and all code will end
				println("smallest: " + x);
				println("largest: " + z);
				break;
			}
			
		}
		
	}
	
	
}


