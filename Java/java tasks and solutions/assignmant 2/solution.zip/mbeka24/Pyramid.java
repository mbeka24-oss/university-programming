/*
 * File: Pyramid.java
 * Name: 
 * Section Leader: 
 * ------------------
 * This file is the starter file for the Pyramid problem.
 * It includes definitions of the constants that match the
 * sample run in the assignment, but you should make sure
 * that changing these values causes the generated display
 * to change accordingly.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Pyramid extends GraphicsProgram {

    /** Width of each brick in pixels */
    private static final int BRICK_WIDTH = 30;

    /** Height of each brick in pixels */
    private static final int BRICK_HEIGHT = 12;

    /** Number of bricks in the base of the pyramid */
    private static final int BRICKS_IN_BASE = 14;

    public void run() {
        int n = BRICKS_IN_BASE; // Total number of levels in the pyramid

        // Loop through each level of the pyramid from top to bottom
        for (int k = 1; k <= n; k++) {
            /** 
             * Calculate the vertical position of the current level.
             * the curent level from the total height of the drawing area.
             */
            int y = getHeight() - BRICK_HEIGHT * k;

            /** 
             * Determine the number of bricks to draw in the current level.
             * As the level number increases, the number of bricks decreases.
             */
            int e = BRICKS_IN_BASE - k + 1;

            // Loop to draw each brick in the current level
            for (int m = 0; m < e; m++) {
                /** 
                 * The total width of the bricks at this level is adjusted to
                 * ensure they are centered in the drawing area.
                 */
                double x = (getWidth() - (BRICKS_IN_BASE - k + 1) * BRICK_WIDTH) / 2 + m * BRICK_WIDTH; 
                add(new GRect(x, y, BRICK_WIDTH, BRICK_HEIGHT));
            }
        }
    }
}